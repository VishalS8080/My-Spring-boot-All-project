package SpringBootOneExample.SpringBootOneExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootOneExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
