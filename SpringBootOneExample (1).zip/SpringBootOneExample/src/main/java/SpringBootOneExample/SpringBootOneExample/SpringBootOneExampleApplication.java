package SpringBootOneExample.SpringBootOneExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootOneExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootOneExampleApplication.class, args);
	}

}
